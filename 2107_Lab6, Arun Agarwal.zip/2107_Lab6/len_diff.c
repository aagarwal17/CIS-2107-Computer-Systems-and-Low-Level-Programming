#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Returns the length of s1 - the length of s2
*/

int len_diff(char *s1, char *s2)
{
   int l1 = 0;
   char* c = s1;
   while( *c != '\0' )
   {
       l1++;
       c++;
   }
   int l2 = 0;
   c = s2;
   while( *c != '\0' )
   {
       l2++;
       c++;
   }
   return l1-l2;  
}