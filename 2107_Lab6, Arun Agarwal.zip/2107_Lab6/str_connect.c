#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"


//Note: This code was written by the Professor and was edited by me to work for my code!

/**********************************************************************
char *str_connect(char **strs, int n, char c)

Returns a string consisting of the first n strings in strs with the
character c used as a separator. For example, if strs contains the
strings {"Washington", "Adams", "Jefferson"}, n is 3, and c is '+',
the function returns the string "Washington+Adams+Jefferson"
**********************************************************************/
char *str_connect(char **strs, int n, char c) {
  char *temp;
  int i;

  /*Iterate and calculate length of each string in the array*/
  //for ()

  char *ret_str = (char *) malloc(1000);
  char *actual_ret = ret_str;

  /* Iterate through each string in strs array */
  for (i = 0; i < n; i++){
    temp = strs[i]; // for i = 0 temp is "Washington" in the example
    int j;
    int len = str_len(temp);
    
    for (j = 0; j < len; j++) {
      *ret_str = *temp;
      ret_str++;
      temp++;
    }
    
    if (i != n-1) {
      *ret_str = c;
      ret_str++;
    }
  }

  *ret_str = '\0';

  return actual_ret;
}