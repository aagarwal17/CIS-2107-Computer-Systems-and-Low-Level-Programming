#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Returns a new string consisting of all of the letters of s, but padded with spaces at the end so that the total length of the returned string is an even multiple of d. 
If the length of s is already an even multiple of d, the function returns a copy of s. 
The function returns NULL on failure or if s is NULL. 
Otherwise, it returns the new string.
It is up to the caller to free any memory allocated by the function
*/

char pad(char *s, int d)
{
    int len1=0;
    while(s[len1]!='\0')
    {
        len1++;
    }
    int div = len1/d;
    int addedSpace=0;
    if(div%2!=0 || div==0)
    {
        do
        {
            addedSpace++;
            div = (len1+addedSpace)/d;
        }
        while(div%2!=0 || div==0);
    }
    int i;
    int count=0;
    char *newPtr =(char *)malloc((len1+addedSpace+1) * sizeof(char));
    for(i=0;i<len1;i++)
    {
        newPtr[count++] = s[i];
    }
    for(i=0;i<addedSpace;i++)
    {
        newPtr[count++] = ' ';
    }
    newPtr[len1+addedSpace]='\0';
    return newPtr;
}