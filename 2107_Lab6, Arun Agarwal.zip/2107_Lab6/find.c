#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
returns the index of the first occurence of n in the string h or -1 if it isn't found.
*/

int find(char *h, char *n)
{
   int counter = 1;
   char *t=h;

   //Iterate through string
   while (*t!='\0')
   {

   //If we find the char then return index number
     if (*t ==*n)
       return counter;

    counter ++;
    t++;
   }
   //If we hit end of string without finding char
   return -1;
}