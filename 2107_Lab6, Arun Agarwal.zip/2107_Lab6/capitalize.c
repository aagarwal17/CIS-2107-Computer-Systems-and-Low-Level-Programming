#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Changes s so that the first letter of every word is in upper case and each additional letter is in lower case.
*/

void capitalize(char *s)
{
    int index = 0;
    int isfirst = 0;
    int i = 0;
    for(i=0;s[i]!='\0';i++)
    {
        isfirst = 0;
        if(i==0 && s[i]!=' ')
        {
            if(s[i]>='a' && s[i]<='z')
            {
                //s[i]='A'+s[i]-'a';
                printf("%c",s[i]-32);
                index++;
                isfirst = 1;
            }
        }

        if(s[i]==' ')
        {
            if(s[i+1] !='\0' && s[i+1]>='a' && s[i+1]<='z')
            {
                //s[i+1]='A'+s[i+1]-'a';
                printf("%c",s[i]);
                printf("%c",s[i+1]-32);
                index++;
                isfirst = 1;
                i++;
            }

        }
        if(isfirst == 0)
        {
            printf("%c",s[i]);
        }
    }
}