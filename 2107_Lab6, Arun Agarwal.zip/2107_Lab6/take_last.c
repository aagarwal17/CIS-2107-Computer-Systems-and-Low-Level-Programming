#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107


/*
Modifies s so that it consists of only its last n characters. If n is ≥ the length of s, the original string is unmodified.
For example if we call take_last("Brubeck" 5), when the function finishes, the original string becomes "ubeck"
*/

void take_last(char *s, int n)
{
    int len1=0;
    while(s[len1]!='\0')
    {
        len1++;
    }
    int i=0;
    int start=len1-n;
    if(n<len1)
    {
        while(start<len1)
        {
            s[i] = s[start];
            i++;
            start++;
        }
        s[i] ='\0';
    }  
}