/*
Created By: Arun Agarwal (with Assistance from Patrick Ammons), CIS 2107, 05/05/2021
*/


#include "string_lib.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>


void assert_str_eq(char *s1, char *s2) 
{
    assert(!strcmp(s1, s2));
}


int main() 
{
    printf("Running test.c tests...\n");

    char *s1 = "Hello, world!";
    char *s2 = "Goodbye";


    assert(str_len(s1) == 13);
    assert(str_len(s2) == 7);
    assert(str_len("") == 0);


    assert(all_letters(s1) == 0);
    assert(all_letters(s2) == 1);
    assert(all_letters("") == 1);


    assert(num_in_range(s1, 'e', 'l') == 4);
    assert(num_in_range(s2, 'A', 'z') == 7);
    assert(num_in_range("", 'A', 'z') == 0);


    assert(diff(s1, "Hello worl") == 3);
    assert(diff(s1, "Jello whirl") == 6);
    assert(diff(s1, "") == 13);


    char *s1_copy = "Hello, world!";
    shorten(s1_copy, 5);
    assert_str_eq(s1_copy, "Hello");

    s1_copy = "Hello, world!";
    shorten(s1_copy, 20);
    assert_str_eq(s1_copy, "Hello, world!");

    s1_copy = "Hello, world!";
    shorten(s1_copy, 13);
    assert_str_eq(s1_copy, "Hello, world!");


    assert(len_diff(s1, s2) == 6);
    assert(len_diff(s2, s1) == -len_diff(s1, s2));
    assert(len_diff(s1, s1) == 0);


    char *s3 = "     Hello, world!  ";
    rm_left_space(s3);
    assert_str_eq(s3, "Hello, world!  ");

    s3 = "Hello, world!  ";
    rm_left_space(s3);
    assert_str_eq(s3, "Hello, world!  ");


    s3 = "";
    rm_left_space(s3);
    assert(*s3 == '\0');

    s3 = "    Hello, world!    ";
    rm_right_space(s3);
    assert_str_eq(s3, "    Hello, world!");

    s3 = "  Hello, world!";
    rm_right_space(s3);
    assert_str_eq(s3, "  Hello, world!");

    s3 = "";
    rm_right_space(s3);
    assert(*s3 == '\0');


    s3 = "     Hello, world!    ";
    rm_space(s3);
    assert_str_eq(s3, "Hello, world!");

    s3 = "    Hello, world!";
    rm_space(s3);
    assert_str_eq(s3, "Hello, world!");

    s3 = "Hello, world!    ";
    rm_space(s3);
    assert_str_eq(s3, "Hello, world!");

    s3 = "Hello, world!";
    rm_space(s3);
    assert_str_eq(s3, "Hello, world!");


    assert(find(s1, "wor") == 7);
    assert(find(s1, "mellow") == -1);
    assert(find(s1, "Hel") == 0);
    assert(find(s1, "ld!") == 10);
    assert(find(s1, "Hello, world!") == 0);
    assert(find("Hello", "Hello, world!") == -1);


    assert_str_eq(ptr_to(s1, "wor"), "world!");
    assert(ptr_to(s1, "mellow") == NULL);
    assert_str_eq(ptr_to(s1, "Hel"), "Hello, world!");
    assert_str_eq(ptr_to(s1, "ld!"), "ld!");
    assert_str_eq(ptr_to(s1, "Hello, world!"), "Hello, world!");


    assert(!is_empty(s1));
    assert(is_empty(""));
    assert(is_empty(NULL));
    assert(is_empty("   \t \n    \r  "));
    assert(!is_empty("      \n \r   x"));
    assert(!is_empty("    Hello, world!"));


    assert_str_eq(str_zip(s1, s2), "HGeololdob,y eworld!");
    assert_str_eq(str_zip("Hello", "world"), "Hweolrllod");
    assert_str_eq(str_zip(s1, ""), s1);
    assert_str_eq(str_zip("", s1), s1);


    s3 = "Hello, world!";
    capitalize(s3);
    assert_str_eq(s3, "Hello, World!");

    s3 = "hE lL oW oR lD !";
    capitalize(s3);
    assert_str_eq(s3, "He Ll Ow Or Ld !");

    s3 = "";
    capitalize(s3);
    assert_str_eq(s3, "");


    assert(strcmp_ign_case(s1, s2) > 0);
    assert(strcmp_ign_case(s2, s1) < 0);
    assert(strcmp_ign_case(s1, s1) == 0);
    assert(strcmp_ign_case(s1, "Hello, world") > 0);
    assert(strcmp_ign_case("", s1) < 0);


    s3 = "Hello, world!";
    take_last(s3, 4);
    assert_str_eq(s3, "rld!");

    take_last(s3, 5);
    assert_str_eq(s3, "rld!");

    take_last(s3, 0);
    assert_str_eq(s3, "");

    s3 = "";
    take_last(s3, 0);
    assert_str_eq(s3, "");


    assert_str_eq(dedup(s1), "Helo, wrd!");
    assert_str_eq(dedup(""), "");
    assert_str_eq(dedup(s2), "Godbye");
    assert_str_eq(dedup("eeeeeeeeeeeeeeeeeeeeeeeee"), "e");


    assert_str_eq(pad(s1, 10), "Hello, world!       ");
    assert_str_eq(pad(s2, 1), s2);
    assert_str_eq(pad(s1, 3), "Hello, world!  ");
    assert_str_eq(pad(s1, 13), "Hello, world!");


    assert(ends_with_ignore_case(s1, "ld!"));
    assert(ends_with_ignore_case(s1, "wORLD!"));
    assert(!ends_with_ignore_case(s1, "wld!"));
    assert(ends_with_ignore_case(s1, s1));


    assert_str_eq(repeat(s2, 3, '!'), "Goodbye!Goodbye!Goodbye");
    assert_str_eq(repeat("", 5, ','), ",,,,");
    assert_str_eq(repeat("Hello!", 0, 'a'), "");
    assert_str_eq(repeat("", 1, 'a'), "");


    assert_str_eq(replace(s1, "l", "yee"), "Heyeeyeeo, woryeed!");
    assert_str_eq(replace("eeeee", "ee", "nice"), "nicenicee");
    assert_str_eq(replace(s1, "", "nope"), s1);
    assert_str_eq(replace("fifty nifty united states", "fty", "fteen thousand"), "fifteen thousand nifteen thousand united states");
    assert_str_eq(replace("never everer", "er", ""), "nev ev");


    char *strs[] = {"A", "B", "C", "D", "E"};
    assert_str_eq(str_connect(strs , 3, ','), "A,B,C");
    assert_str_eq(str_connect(strs, 5, '!'), "A!B!C!D!E");
    assert_str_eq(str_connect(strs, 0, 'b'), "");

    char *strs2[] = {"yeet"};
    assert_str_eq(str_connect(strs2, 0, 'k'), "");
    assert_str_eq(str_connect(strs2, 1, 'h'), "yeet");

    char *strs3[] = {"hello", "world", "how's", "it", "goin'?"};
    assert_str_eq(str_connect(strs3, 4, ' '), "hello world how's it");
    assert(str_len(str_connect(strs3, 3, ' ')) == 5+1+5+1+5);


    char *strs4[] = {"", "a", "b", "", "c", "d", "", "", "k", NULL};
    rm_empties(strs4);
    assert_str_eq(*strs4, "a");
    assert_str_eq(*(strs4 + 1), "b");
    assert_str_eq(*(strs4 + 2), "c");
    assert_str_eq(*(strs4 + 3), "d");
    assert_str_eq(*(strs4 + 4), "k");
    assert(*(strs4 + 5) == NULL);


    char **res = str_chop_all(" Hello, world!  What a beautiful day!", ' ');
    int expect_len = 8, i;
    char *expect[] = {"", "Hello,", "world!", "", "What", "a", "beautiful", "day!", NULL};
    for (i = 0; i < expect_len; i++) {
        assert_str_eq(res[i], expect[i]);
    }

    res = str_chop_all("Hello,world!Whatabeautifulday!", ' ');
    expect_len = 1;
    expect[0] = "Hello,world!Whatabeautifulday!";
    expect[1] = NULL;
    for (i = 0; i < expect_len; i++) {
        assert_str_eq(res[i], expect[i]);
    }


    printf("All tests passed.\n");
}