#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Compares s1 and s2 ignoring case.
Returns a positive number if s1 would appear after s2 in the dictionary, a negative number if it would appear before s2, or 0 if the two are equal.
*/

int strcmp_ign_case(char *s1, char *s2)
{
    int i =0;
    for( i=0;s1[i]!='\0' && s2[i]!='\0';i++)
    {
        char ch1,ch2;
        ch1 = s1[i];
        ch2 = s2[i];
        if(s1[i]>='A' && s1[i]<='Z')
        {
            ch1 = s1[i]+32;
        }
        if(s2[i]>='A' && s2[i]<='Z')
        {
            ch2 = s2[i]+32;
        }
        if(ch1 != ch2)
        {
            return ch1-ch2;
        }
    }
    if(s1[i]=='\0' && s2[i]=='\0')
    {
        return 0;
    }
    else
    {
        return s1[i]-s2[i];
    }
    return 0;
}