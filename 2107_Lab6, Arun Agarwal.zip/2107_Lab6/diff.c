#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
returns the number of positions in which s1 and s2 differ
i.e., it returns the number of changes that would need to be made in order to transform s1 into s2, where a change could be a character substitution, an insertion, or a deletion.
*/

//I created a helper method for difference
int diffHelper(char *s1, char *s2, int l1, int l2) 
{
        if(l1 == 0) return l2;
        if(l2 == 0) return l1;

        //If the last characters are the same
        if(s1[l1-1] == s2[l2-1]) 
        { 
            return diffHelper(s1, s2, l1-1, l2-1); 
        }

        int onInsert = diffHelper(s1, s2, l1, l2-1);
        int onRemoval = diffHelper(s1, s2, l1-1, l2);
        int onReplace = diffHelper(s1, s2, l1-1, l2-1);

        int minVal = (onInsert > onRemoval ? (onRemoval > onReplace ? onReplace : onRemoval) : (onInsert > onReplace ? onReplace : onInsert) );
        return 1 + minVal;
}

//diff calls the helper method
int diff(char *s1, char *s2) 
{
     return diffHelper(s1, s2, str_len(s1), str_len(s2));
}