#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Returns 1 if s is NULL, consists of only the null character ('') or only whitespace. 
Returns 0 otherwise.
*/

int is_empty(char *s)
{
  char *t=s;
  int counter = 0;
  while (*t!='\0') 
  {
    counter ++;
    t++;
  }
  if (counter > 0)
  {
    return 0;
  }  
  return 1;
}