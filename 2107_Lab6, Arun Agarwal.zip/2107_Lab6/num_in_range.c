#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Returns the number of characters c in s1 such that b<=c<=t
*/

int num_in_range(char *s, char b, char t) 
{
    int i = 0;
    while(*s) 
    {
        if(*s >= b && *s <= t) 
        {
            i++;
        }
        s++;
    }
    return i;
}