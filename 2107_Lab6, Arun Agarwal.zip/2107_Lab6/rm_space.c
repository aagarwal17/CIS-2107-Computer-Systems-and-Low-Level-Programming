#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
removes whitespace characters from the beginning and the ending s
*/

void rm_space(char *s)
{
   rm_left_space(s);
   rm_right_space(s);
}