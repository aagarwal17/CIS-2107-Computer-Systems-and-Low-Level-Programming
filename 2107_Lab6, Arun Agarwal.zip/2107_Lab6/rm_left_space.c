#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
removes whitespace characters from the beginning of s
*/

void rm_left_space(char *s) 
{
    /*while(isspace(*s)) 
    {
        s++;
    }
    return s;*/

   int blankSpaceEndAt = 0;
   char* c = s;
   while(*c != '\0' && *c == ' ')
   { 
       c++;
       blankSpaceEndAt++; 
   }
   c = s + blankSpaceEndAt;
   while(*c != '\0')
   {
       *s = *c;
       c++;
       s++;
   }
   *s = '\0';
}