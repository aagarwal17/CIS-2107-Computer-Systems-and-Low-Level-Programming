#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Returns a new string based on s, but without any duplicate characters.
For example, if s is the string, "There's always money in the banana stand.", the function returns the string "Ther's alwymonitbd."
It is up to the caller to free the memory allocated by the function.
*/

char dedup(char *s)
{
    int len1=0;
    while(s[len1]!='\0')
    {
        len1++;
    }
    char *newPtr =(char *)malloc((len1+1) * sizeof(char));
    int count=0;
    int i,j;
    char c;
    int found=0;
    for(i=0;i<len1;i++)
    {
        c= s[i];
        found=0;
        for(j=0;j<count;j++)
        {
            if(newPtr[j]==c)
            {
                found=1;
                break;
            }
        }
        if(found==0)
        {
            newPtr[count]=c;
            count++;
        }
    }
    newPtr[count]='\0';
    return newPtr;
}    