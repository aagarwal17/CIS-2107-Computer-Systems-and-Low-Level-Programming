#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Returns a new string consisting of all of the characters of s1 and s2 interleaved with each other. 
For example, if s1 is "Spongebob" and s2 is "Patrick", the function returns the string "SPpaotnrgiecbkob"
*/

char* str_zip(char *s1, char *s2)
{
    int len1=0;
    int len2=0;
    while(s1[len1]!='\0')
    {
        len1++;
    }
    while(s2[len2]!='\0')
    {
        len2++;
    }
}