#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Shortens the string s to new_len.
If the original length of s is less than or equal to new_len, s is unchanged
*/

void shorten(char *s, int new_len)
{
    int len=myStrlen(s);

    //If string length is less than the given length, the string will remain unchanged:
    if(len<=new_len) 
        printf("string is unchanged");
    else
    {
        int i; //else
        for(i=new_len;i<len;i++)
        {
        //Terminate the string by putting null character; string is shortened
        s[i]='\0'; 
        }
    }
}