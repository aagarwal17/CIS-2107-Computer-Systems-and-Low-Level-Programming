#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Words is an array of string terminated with a NULL pointer.
The function removes any empty strings (i.e., strings of length 0) from the array.
*/

void rm_empties(char **words)
{
    int i=0, j, k, len, p = 0;
    //Loop till all strings are processed
    while(words[i] != NULL)
    {
        len = 0;
        //Finding length of string
        for(j=0; words[i][j] != '\0'; j++)
        len++;

        if(len == 0)
        {
            k = i;
            //Removing element by adjusting element of array
            while(words[k+1] != NULL)
            {
                //Swapping
                words[k] = words[k+1];
                k++;
            }
            //Incrementing number of elements removed
            p++;
        }
        else
        {
            i++;
        }
    }
    //Adding null pointer
    words[(i-p)] = NULL;
}