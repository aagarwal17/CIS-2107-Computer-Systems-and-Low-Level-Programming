#include <stdlib.h>
#include <stdio.h>
#include "string_lib.h"
//Created By: Arun Agarwal, 05/01/2021, CIS 2107

/*
Returns the number of characters in the string s (up to but not including the '\0' character).
Note: Use pointer notation, not array notation for this. 
An example strlen implementation is shown below. 
Before just using this code, please understand what it is doing (you will be asked to explain why that code works). 
There are multiple ways you could implement this, so if your implementation is different from the below example, that is not a problem (as long as it works correctly of course).
*/

int str_len(char *s)
{
   char *t=s;

   while (*t!='\0')
      t++;
   return t-s;
}

/*My first take of this method:
int str_len(char *s) 
{
    int i = 0;
    while(*s) 
    {
        s++;
        i++;
    }
    return i;
}*/